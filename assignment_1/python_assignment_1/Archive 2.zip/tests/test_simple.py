import unittest
from chrono import Timer
from gradescope_utils.autograder_utils.decorators import weight, number, visibility
from removeDuplicates import removeDuplicates

runTime = 0.0

class TestRemoveDuplicates(unittest.TestCase):
    with Timer() as timed: 
        @visibility("after_due_date")
        @weight(1)
        @number("1")
        def test_eval_eq(self):
            """Test Case 1"""
            val = removeDuplicates([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
            self.assertEqual(val, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])

        @visibility("after_due_date")
        @weight(1)
        @number("2")
        def test_eval_all_one(self):
            """Test Case 2"""
            val = removeDuplicates([1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3])
            self.assertEqual(val, [1, 2, 3])

        @visibility("after_due_date")
        @weight(1)
        @number("3")
        def test_eval_emptyl(self):
            """Test Case 3"""
            val = removeDuplicates([])
            self.assertEqual(val, [])
    
    runTime = timed.elapsed